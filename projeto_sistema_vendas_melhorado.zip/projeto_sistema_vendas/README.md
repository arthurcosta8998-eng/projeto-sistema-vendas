# Sistema de Vendas — Consulta de Produtos

Projeto acadêmico desenvolvido para a disciplina **Banco de Dados II** da ETEC, com o objetivo de praticar a modelagem de banco de dados, a escrita de consultas SQL e a integração de uma página PHP com um banco de dados MySQL.

---

## 1. Objetivo do Projeto

O sistema apresenta uma listagem dos produtos cadastrados no banco de dados `db_sistema_vendas`.  
A página PHP executa um comando `SELECT` com `INNER JOIN` e exibe os seguintes dados:

- Código (ID) do produto
- Nome do produto
- Categoria
- Preço (formatado em Real)
- Quantidade em estoque

---

## 2. Tecnologias Utilizadas

| Tecnologia     | Finalidade                                      |
|----------------|-------------------------------------------------|
| PHP            | Conexão com o banco e geração dinâmica da página |
| MySQL 8        | Armazenamento dos dados e execução das consultas |
| HTML5          | Estrutura da página                             |
| CSS3           | Formatação visual da tabela                     |
| MySQLi         | Comunicação entre PHP e MySQL                   |

---

## 3. Estrutura dos Arquivos

| Arquivo        | Descrição                                                                 |
|----------------|---------------------------------------------------------------------------|
| `index.php`    | Página principal. Realiza a consulta e exibe os produtos em uma tabela HTML |
| `conexao.php`  | Arquivo responsável pela conexão com o banco de dados                     |
| `fisico.sql`   | Script completo de criação do banco, tabelas, inserção de dados e consultas |
| `README.md`    | Documentação completa do projeto                                           |
| `.gitignore`   | Arquivo para ignorar arquivos sensíveis e temporários                     |

---

## 4. Modelagem do Banco de Dados

O banco de dados se chama **`db_sistema_vendas`** e possui as seguintes tabelas:

### 4.1 Tabelas criadas

| Tabela            | Descrição                                      | Principais campos                          |
|-------------------|------------------------------------------------|--------------------------------------------|
| `tbl_clientes`    | Cadastro de clientes                           | id, nome, email, cidade                    |
| `tbl_vendedores`  | Cadastro de vendedores                         | id, nome, percentual_comissao              |
| `tbl_produtos`    | Cadastro de produtos                           | id, nome, preco, quantidade, id_categoria  |
| `tbl_pedidos`     | Registro de pedidos                            | id, id_cliente, id_vendedor, status        |
| `tbl_categorias`  | Categorias dos produtos                        | id, nome                                   |

### 4.2 Relacionamentos

- `tbl_produtos.id_categoria` → `tbl_categorias.id` (Chave Estrangeira)
- `tbl_pedidos.id_cliente` → `tbl_clientes.id`
- `tbl_pedidos.id_vendedor` → `tbl_vendedores.id`

### 4.3 Restrições importantes

- Chaves primárias com `AUTO_INCREMENT`
- Uso do motor **InnoDB** (suporte a transações e chaves estrangeiras)
- Restrição `CHECK` na coluna `preco` para impedir valores negativos ou zero
- Campo `email` com restrição `UNIQUE`
- Valor padrão (`DEFAULT`) na coluna `cidade`

### 4.4 Quantidade de registros de exemplo

- 30 clientes
- 10 vendedores
- 150 produtos
- 50 pedidos

---

## 5. Etapas de Desenvolvimento (passo a passo)

### Etapa 1 — Criação do banco de dados
Foi criado o banco `db_sistema_vendas` com charset `utf8mb4` e collation `utf8mb4_unicode_ci` para suporte completo a acentos e caracteres especiais.

### Etapa 2 — Criação das tabelas principais
Foram criadas as tabelas `tbl_clientes`, `tbl_vendedores`, `tbl_produtos` e `tbl_pedidos` com suas respectivas chaves primárias e restrições.

### Etapa 3 — Definição de relacionamentos
Foram definidas as chaves estrangeiras entre pedidos, clientes e vendedores.

### Etapa 4 — Melhoria da tabela de produtos
Foi adicionada a coluna `quantidade` para controlar o estoque de cada produto.

### Etapa 5 — Normalização das categorias
Inicialmente as categorias estavam gravadas como texto dentro da tabela de produtos.  
Foi criada a tabela `tbl_categorias` e realizada a migração dos dados:

1. Extração das categorias distintas
2. Inserção na nova tabela `tbl_categorias`
3. Criação da coluna `id_categoria` em `tbl_produtos`
4. Atualização dos registros com o ID correto da categoria
5. Criação da chave estrangeira
6. Remoção da coluna antiga de texto (`categoria`)

### Etapa 6 — Inserção de dados de exemplo
Foram inseridos dados fictícios para clientes, vendedores, produtos e pedidos, permitindo testes realistas das consultas.

### Etapa 7 — Elaboração de consultas SQL
Foram desenvolvidas diversas consultas de diferentes níveis de complexidade:

- Projeção de colunas (`SELECT`)
- Uso de alias (`AS`)
- Filtros com `WHERE`
- Operadores lógicos (`AND` / `OR`)
- Faixas de valores (`BETWEEN`)
- Conjuntos de valores (`IN`)
- Busca por padrões (`LIKE`)
- Junções (`INNER JOIN`)
- Ordenação (`ORDER BY`)

### Etapa 8 — Desenvolvimento da conexão PHP
Criado o arquivo `conexao.php` utilizando a extensão **MySQLi**, com tratamento de erro e definição de charset `utf8mb4`.

### Etapa 9 — Desenvolvimento da página de consulta
Criado o arquivo `index.php` que:

- Inclui o arquivo de conexão
- Executa a consulta principal com `JOIN`
- Exibe os resultados em uma tabela HTML formatada com CSS
- Formata o preço no padrão brasileiro (R$ 1.234,56)
- Utiliza `htmlspecialchars` para segurança básica

### Etapa 10 — Testes
O sistema foi testado localmente com XAMPP, verificando:

- Conexão com o banco
- Execução correta da consulta
- Exibição adequada dos dados
- Formatação visual da tabela

---

## 6. Consulta Principal Utilizada

```sql
SELECT
    p.id,
    p.nome AS produto,
    p.preco,
    p.quantidade,
    c.nome AS categoria
FROM tbl_produtos AS p
INNER JOIN tbl_categorias AS c
    ON p.id_categoria = c.id
ORDER BY p.id ASC;
```

Esta consulta utiliza `INNER JOIN` para trazer o nome da categoria junto com os dados do produto.

---

## 7. Como Instalar e Executar o Projeto

### Pré-requisitos
- XAMPP (Apache + MySQL + PHP) ou ambiente similar
- Navegador de internet

### Passo a passo

1. **Baixar e extrair o projeto**
2. **Copiar a pasta** `projeto_sistema_vendas` para dentro da pasta `htdocs` do XAMPP
3. **Iniciar** os serviços Apache e MySQL no painel do XAMPP
4. **Abrir o phpMyAdmin** (`http://localhost/phpmyadmin`)
5. **Importar** o arquivo `fisico.sql`
6. **Acessar** no navegador:  
   `http://localhost/projeto_sistema_vendas/`

---

## 8. Possíveis Melhorias Futuras

- Telas de cadastro, edição e exclusão de produtos
- Sistema de pesquisa e filtros
- Paginação dos resultados
- Validação de formulários
- Autenticação de usuários
- Relatórios de vendas
- Controle de estoque mais avançado

---

## 9. Observações Finais

Este é um projeto acadêmico desenvolvido para fins de aprendizado.  
Os dados utilizados são fictícios e o sistema deve ser executado apenas em ambiente local de testes.

---

**Aluno:** Arthur Costa  
**Disciplina:** Banco de Dados II  
**Instituição:** ETEC  
**Data:** Novembro/2026
