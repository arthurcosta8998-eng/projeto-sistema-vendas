<?php

require_once "conexao.php";

$sql = "SELECT
            p.id,
            p.nome AS produto,
            p.preco,
            p.quantidade,
            c.nome AS categoria
        FROM tbl_produtos AS p
        INNER JOIN tbl_categorias AS c
            ON p.id_categoria = c.id
        ORDER BY p.id ASC";

$resultado = mysqli_query($conexao, $sql);

if (!$resultado) {
    die("Erro na consulta: " . mysqli_error($conexao));
}

?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ETEC - Sistema de Vendas | Consulta de Produtos</title>

    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Segoe UI', Arial, sans-serif;
            background-color: #f0f2f5;
            color: #333;
            line-height: 1.5;
            padding: 20px;
        }

        .container {
            max-width: 1100px;
            margin: 0 auto;
            background: #ffffff;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
            overflow: hidden;
        }

        header {
            background: linear-gradient(135deg, #007bff, #0056b3);
            color: white;
            padding: 24px 30px;
        }

        header h1 {
            font-size: 1.6rem;
            margin-bottom: 6px;
        }

        header p {
            font-size: 0.95rem;
            opacity: 0.9;
        }

        .content {
            padding: 25px 30px;
        }

        .info {
            background: #e8f4fd;
            border-left: 4px solid #007bff;
            padding: 12px 16px;
            margin-bottom: 22px;
            border-radius: 0 6px 6px 0;
            font-size: 0.95rem;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 0.95rem;
        }

        thead {
            background-color: #007bff;
            color: white;
        }

        th, td {
            padding: 12px 14px;
            text-align: left;
            border-bottom: 1px solid #e0e0e0;
        }

        th {
            font-weight: 600;
            letter-spacing: 0.3px;
        }

        tbody tr:nth-child(even) {
            background-color: #f8f9fa;
        }

        tbody tr:hover {
            background-color: #e3f2fd;
        }

        .preco {
            font-weight: 600;
            color: #198754;
        }

        .estoque {
            text-align: center;
        }

        footer {
            text-align: center;
            padding: 16px;
            font-size: 0.85rem;
            color: #777;
            background: #f8f9fa;
            border-top: 1px solid #eee;
        }

        @media (max-width: 700px) {
            body {
                padding: 10px;
            }

            header, .content {
                padding: 18px;
            }

            table {
                font-size: 0.85rem;
            }

            th, td {
                padding: 8px 10px;
            }
        }
    </style>
</head>

<body>

    <div class="container">

        <header>
            <h1>Sistema de Vendas</h1>
            <p>Consulta de Produtos — Disciplina Banco de Dados II | ETEC</p>
        </header>

        <div class="content">

            <div class="info">
                Esta página executa um comando <strong>SELECT</strong> com <strong>INNER JOIN</strong>
                no MySQL e exibe os produtos cadastrados no banco de dados.
            </div>

            <table>
                <thead>
                    <tr>
                        <th>Código (ID)</th>
                        <th>Nome do Produto</th>
                        <th>Categoria</th>
                        <th>Preço (R$)</th>
                        <th class="estoque">Estoque</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($linha = mysqli_fetch_assoc($resultado)): ?>
                        <tr>
                            <td><?= htmlspecialchars($linha['id']) ?></td>
                            <td><?= htmlspecialchars($linha['produto']) ?></td>
                            <td><?= htmlspecialchars($linha['categoria']) ?></td>
                            <td class="preco">
                                R$ <?= number_format($linha['preco'], 2, ',', '.') ?>
                            </td>
                            <td class="estoque"><?= htmlspecialchars($linha['quantidade']) ?></td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>

        </div>

        <footer>
            Projeto acadêmico — Banco de Dados II | ETEC — 2026
        </footer>

    </div>

</body>

</html>

<?php
mysqli_close($conexao);
?>
