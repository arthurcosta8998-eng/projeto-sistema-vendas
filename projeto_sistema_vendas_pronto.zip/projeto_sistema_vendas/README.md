# Sistema de Vendas — Consulta de Produtos

Projeto acadêmico desenvolvido para a disciplina **Banco de Dados II**, da ETEC, com o objetivo de praticar modelagem e consultas SQL e a integração de uma página PHP com um banco de dados MySQL.

## 1. Objetivo

O sistema apresenta uma listagem dos produtos cadastrados no banco `db_sistema_vendas`. A página consulta os dados usando `SELECT` e exibe:

- Código (ID) do produto;
- Nome do produto;
- Categoria;
- Preço;
- Quantidade em estoque.

## 2. Tecnologias utilizadas

- **PHP** — conexão com o banco e geração dinâmica da página;
- **MySQL 8 ou compatível** — armazenamento dos dados e execução das consultas;
- **HTML5** — estrutura da página;
- **CSS3** — formatação visual da tabela;
- **MySQLi** — comunicação entre PHP e MySQL.

## 3. Estrutura dos arquivos

| Arquivo | Descrição |
|---|---|
| `index.php` | Consulta os produtos e apresenta os resultados em uma tabela HTML. |
| `conexao.php` | Configura e realiza a conexão com o banco de dados. |
| `fisico.sql` | Cria e popula o banco, cria as tabelas e contém consultas SQL usadas no projeto. |
| `README.md` | Documentação do projeto e instruções de instalação e execução. |

## 4. Estrutura do banco de dados

O banco utilizado é `db_sistema_vendas`. O script SQL cria as seguintes tabelas:

- **`tbl_clientes`**: armazena nome, e-mail e cidade dos clientes.
- **`tbl_vendedores`**: armazena nome e percentual de comissão dos vendedores.
- **`tbl_produtos`**: armazena nome, preço e quantidade dos produtos, além da referência à categoria.
- **`tbl_pedidos`**: relaciona clientes e vendedores e registra o status do pedido.
- **`tbl_categorias`**: mantém as categorias dos produtos em uma tabela própria.

As tabelas utilizam chaves primárias e relacionamentos por chaves estrangeiras. A tabela de produtos possui uma restrição `CHECK` para impedir preços não positivos.

O conjunto de dados de exemplo contém 30 clientes, 10 vendedores, 150 produtos e 50 pedidos.

## 5. Como instalar e executar

### Pré-requisitos

- XAMPP (ou outro ambiente com Apache, PHP e MySQL);
- MySQL 8 ou versão compatível;
- Navegador de internet.

### Passo 1 — Copiar os arquivos

1. Extraia a pasta do projeto.
2. Copie a pasta `projeto_sistema_vendas` para a pasta `htdocs` do XAMPP.
3. Inicie os serviços **Apache** e **MySQL** no painel do XAMPP.

### Passo 2 — Criar o banco de dados

1. Abra o phpMyAdmin em `http://localhost/phpmyadmin`.
2. Selecione a opção **Importar**.
3. Escolha o arquivo `fisico.sql` deste projeto.
4. Execute a importação e aguarde a criação e a população das tabelas.

> Atenção: o script foi preparado para criar o banco e as tabelas do zero. Se já existir um banco com essas tabelas, faça uma cópia de segurança antes de importar novamente ou remova o banco de teste anterior.

### Passo 3 — Configurar a conexão

Abra `conexao.php` e confira os dados de acesso ao MySQL. Por padrão, o projeto considera:

- Host: `localhost`
- Usuário: `root`
- Senha: vazia
- Banco: `db_sistema_vendas`

Se seu MySQL local utiliza outra senha, configure-a no arquivo ou defina as variáveis de ambiente `DB_HOST`, `DB_USER`, `DB_PASSWORD` e `DB_NAME`.

**Segurança:** não coloque senhas reais, tokens ou outros dados privados em um repositório público.

### Passo 4 — Abrir o sistema

Com Apache e MySQL ativos, acesse:

`http://localhost/projeto_sistema_vendas/`

A página deverá mostrar a lista de produtos cadastrados, ordenada pelo ID.

## 6. Funcionamento do código

1. O arquivo `index.php` inclui `conexao.php` usando `require_once`.
2. `conexao.php` estabelece a conexão com o MySQL usando `mysqli_connect`.
3. O sistema executa uma consulta SQL que relaciona `tbl_produtos` e `tbl_categorias` por meio de `INNER JOIN`.
4. Os resultados são percorridos com `mysqli_fetch_assoc`.
5. Os valores são apresentados na tabela HTML. A função `htmlspecialchars` é utilizada para exibir os textos com segurança.
6. O preço é formatado para o padrão brasileiro com `number_format`.
7. Ao final, a conexão com o banco é encerrada.

## 7. Consulta principal

A consulta usada pela página é:

```sql
SELECT
    p.id,
    p.nome AS produto,
    p.preco,
    p.quantidade,
    c.nome AS categoria
FROM tbl_produtos AS p
INNER JOIN tbl_categorias AS c
    ON p.id_categoria = c.id
ORDER BY p.id ASC;
```

O `INNER JOIN` permite apresentar o nome da categoria associado a cada produto. O `ORDER BY` organiza a listagem em ordem crescente de identificação.

## 8. Etapas de desenvolvimento

1. Criação do banco de dados `db_sistema_vendas`.
2. Criação das tabelas de clientes, vendedores, produtos e pedidos.
3. Definição de chaves primárias, chaves estrangeiras e restrições.
4. Inclusão da coluna de quantidade no cadastro de produtos.
5. Criação da tabela de categorias.
6. Migração das categorias que estavam registradas diretamente em produtos para a tabela `tbl_categorias`.
7. Relacionamento entre produtos e categorias por meio da coluna `id_categoria`.
8. Inserção dos dados de exemplo.
9. Elaboração de consultas SQL com projeção, filtros, operadores lógicos, `BETWEEN`, `IN`, `LIKE`, `JOIN` e ordenação.
10. Desenvolvimento da conexão PHP com MySQL.
11. Desenvolvimento da página HTML que apresenta os produtos em uma tabela.
12. Teste da consulta e da exibição dos dados no navegador.

## 9. Possíveis melhorias futuras

- Criar telas para cadastrar, editar e excluir produtos;
- Adicionar pesquisa por nome e categoria;
- Implementar paginação;
- Validar os dados enviados por formulários;
- Criar autenticação de usuários e controle de permissões.

## 10. Observações

Este projeto é uma atividade acadêmica e utiliza dados fictícios para demonstração. O script SQL e a aplicação devem ser executados em ambiente local de testes antes de qualquer publicação em produção.
