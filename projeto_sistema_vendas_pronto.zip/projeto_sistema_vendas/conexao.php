<?php
/**
 * Conexão com o banco de dados db_sistema_vendas.
 *
 * Para ambientes locais (XAMPP, por exemplo), os valores abaixo são os padrões.
 * Em hospedagem, configure as variáveis de ambiente DB_HOST, DB_USER,
 * DB_PASSWORD e DB_NAME. Não publique senhas reais no GitHub.
 */

$host = getenv('DB_HOST') ?: 'localhost';
$usuario = getenv('DB_USER') ?: 'root';
$senha = getenv('DB_PASSWORD') !== false ? getenv('DB_PASSWORD') : '';
$banco = getenv('DB_NAME') ?: 'db_sistema_vendas';

$conexao = mysqli_connect($host, $usuario, $senha, $banco);

if (!$conexao) {
    http_response_code(500);
    die("Não foi possível conectar ao banco de dados. Verifique as configurações.");
}

mysqli_set_charset($conexao, "utf8mb4");
?>
